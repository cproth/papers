This folder contains the data and scripts to replicate the results of the paper "Beliefs About Racial Discrimination and Support for Pro-Black Policies" by Ingar Haaland and Christopher Roth. 

Analysis was conducted with Stata 16.

The "data" folder contains the main datasets required to replicate the results in the paper. Some questions asked in some of the surveys have been removed for privacy purposes (e.g. zip code).
 
The "analysis" folder contains all scripts used to generate the results of the paper. 
- before running any of the do files in Stata, customize your paths in the "setup_analysis.do" (a table folder, a figure folder, a data folder, and a directory folder) 
- the supporting documents for the main data set (Experiment 1 with NORC) is available on the following link: https://osf.io/5vm8g/. A cleaned Stata version of the original data set provided by NORC (T007_HAALAND_11JULY17.sav in the zip folder available on the following link: https://osf.io/zqad9/) is included in the analysis. The do file used to clean the NORC data is provided in the "cleaning" folder.


